<?php

declare(strict_types=1);

return ['driver' => 'pdo_sqlite', 'memory' => true];
