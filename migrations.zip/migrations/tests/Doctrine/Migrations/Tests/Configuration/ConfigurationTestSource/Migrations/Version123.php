<?php

declare(strict_types=1);

namespace Migrations\IncorrectNamespace;

class Version123
{
}
