<?php

declare(strict_types=1);

return ['custom_template' => 'template.tpl'];
