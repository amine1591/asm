<?php

declare(strict_types=1);

return ['organize_migrations' => 'year'];
