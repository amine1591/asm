<?php

declare(strict_types=1);

namespace Doctrine\Tests\Models\Cache;

use Doctrine\ORM\Mapping\Entity;

/**
 * @Entity
 */
class Beach extends Attraction
{
}
