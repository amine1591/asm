<?php

declare(strict_types=1);

namespace Doctrine\Tests\Models\DDC753;

class DDC753InvalidRepository
{
}
