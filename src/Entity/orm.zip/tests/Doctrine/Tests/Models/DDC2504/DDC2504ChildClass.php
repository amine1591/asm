<?php

declare(strict_types=1);

namespace Doctrine\Tests\Models\DDC2504;

use Doctrine\ORM\Mapping\Entity;

/**
 * @Entity
 */
class DDC2504ChildClass extends DDC2504RootClass
{
}
