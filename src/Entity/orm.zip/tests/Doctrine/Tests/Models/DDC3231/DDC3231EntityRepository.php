<?php

declare(strict_types=1);

namespace Doctrine\Tests\Models\DDC3231;

use Doctrine\ORM\EntityRepository;

class DDC3231EntityRepository extends EntityRepository
{
}
