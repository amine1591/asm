<?php

declare(strict_types=1);

namespace Doctrine\Tests\Models\OrnementalOrphanRemoval;

class Person
{
    /** @var string */
    public $id;
}
