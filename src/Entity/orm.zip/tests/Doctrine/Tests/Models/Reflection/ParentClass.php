<?php

declare(strict_types=1);

namespace Doctrine\Tests\Models\Reflection;

class ParentClass
{
    /** @var string */
    private $privatePropertyOverride = 'privatePropertyOverride';
}
