<?php

declare(strict_types=1);

namespace Doctrine\Tests\Models\JoinedInheritanceType;

use Doctrine\ORM\Mapping\Entity;

/**
 * @Entity
 */
class AnotherChildClass extends ChildClass
{
}
