<?php

throw new \PHPUnit\Framework\AssertionFailedError('Response body should not be evaluated.');
